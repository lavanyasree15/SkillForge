package skillforge;

public enum Difficulty {
    EASY,
    MEDIUM,
    HARD
}
