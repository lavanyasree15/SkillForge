package skillforge;

public enum Platform {
    LEETCODE,
    CODECHEF,
    CODEFORCES,
    INTERVIEWBIT,
    HACKERRANK,
    HACKEREARTH,
    ATCODER,
    TAKEUFORWARD
}
