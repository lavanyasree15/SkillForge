package skillforge;

public class Main {
    public static void main(String[] args) {
        SkillForgeApp app = new SkillForgeApp();
        app.runMenu();
    }
}
