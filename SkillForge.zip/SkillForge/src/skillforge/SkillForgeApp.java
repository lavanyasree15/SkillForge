package skillforge;

import java.util.*;
import java.io.*;
import java.time.LocalDate;

public class SkillForgeApp {
    List<PracticeEntry> practiceLog = new ArrayList<>();
    List<TestEntry> testLog = new ArrayList<>();
    Scanner scanner = new Scanner(System.in);

    final String PRACTICE_FILE = "data/practice_log.csv";
    final String TEST_FILE = "data/test_log.csv";

    public void loadData() {
        practiceLog.clear();
        testLog.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(PRACTICE_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) practiceLog.add(PracticeEntry.fromCSV(line));
            }
        } catch (IOException ignored) {}
        try (BufferedReader br = new BufferedReader(new FileReader(TEST_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) testLog.add(TestEntry.fromCSV(line));
            }
        } catch (IOException ignored) {}
    }

    public void saveData() {
        try (PrintWriter pw = new PrintWriter(PRACTICE_FILE)) {
            for (PracticeEntry entry : practiceLog) pw.println(entry.toCSV());
        } catch (IOException e) { System.out.println("Error saving practice log"); }

        try (PrintWriter pw = new PrintWriter(TEST_FILE)) {
            for (TestEntry entry : testLog) pw.println(entry.toCSV());
        } catch (IOException e) { System.out.println("Error saving test log"); }
    }

    // Platform selection
    public Platform selectPlatform() {
        while (true) {
            System.out.println("Select Platform:");
            int i = 1;
            for (Platform plat : Platform.values()) {
                System.out.printf("%d. %s\n", i++, plat);
            }
            System.out.print("Enter number (1-" + Platform.values().length + "): ");
            String input = scanner.nextLine();
            try {
                int choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= Platform.values().length) {
                    return Platform.values()[choice - 1];
                }
            } catch(NumberFormatException e) {}
            System.out.println("Invalid input. Try again.");
        }
    }

    // Difficulty selection
    public Difficulty selectDifficulty() {
        while (true) {
            System.out.println("Select Difficulty:");
            int i = 1;
            for (Difficulty diff : Difficulty.values()) {
                System.out.printf("%d. %s\n", i++, diff);
            }
            System.out.print("Enter number (1-" + Difficulty.values().length + "): ");
            String input = scanner.nextLine();
            try {
                int choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= Difficulty.values().length) {
                    return Difficulty.values()[choice - 1];
                }
            } catch(NumberFormatException e) {}
            System.out.println("Invalid input. Try again.");
        }
    }

    public void addPracticeEntry() {
        Platform platform = selectPlatform();
        System.out.print("Problem name: ");
        String problemName = scanner.nextLine();

        // Robust date input
        LocalDate date = null;
        while (date == null) {
            System.out.print("Date (YYYY-MM-DD, leave blank for today): ");
            String dateStr = scanner.nextLine().trim();
            if (dateStr.isEmpty()) {
                date = LocalDate.now();
            } else {
                try {
                    date = LocalDate.parse(dateStr);
                } catch (Exception e) {
                    System.out.println("Invalid date format! Please enter in YYYY-MM-DD format.");
                }
            }
        }

        System.out.print("Status (Solved/Attempted): ");
        String status = scanner.nextLine();
        Difficulty difficulty = selectDifficulty();
        System.out.print("Notes (optional): ");
        String notes = scanner.nextLine();

        practiceLog.add(new PracticeEntry(platform, problemName, date, status, difficulty, notes));
        saveData();
        System.out.println("Practice entry added!\n");
    }


    public void addTestEntry() {
        Platform platform = selectPlatform();
        System.out.print("Test name: ");
        String testName = scanner.nextLine();

        // Robust date input
        LocalDate date = null;
        while (date == null) {
            System.out.print("Date (YYYY-MM-DD, leave blank for today): ");
            String dateStr = scanner.nextLine().trim();
            if (dateStr.isEmpty()) {
                date = LocalDate.now();
            } else {
                try {
                    date = LocalDate.parse(dateStr);
                } catch (Exception e) {
                    System.out.println("Invalid date format! Please enter in YYYY-MM-DD format.");
                }
            }
        }

        System.out.print("Score: ");
        int score = Integer.parseInt(scanner.nextLine());
        System.out.print("Feedback: ");
        String feedback = scanner.nextLine();

        testLog.add(new TestEntry(platform, testName, date, score, feedback));
        saveData();
        System.out.println("Test entry added!\n");
    }


    public void showSummary() {
        System.out.println("\n=== Practice Log ===");
        for (PracticeEntry entry : practiceLog) System.out.println(entry);

        System.out.println("\n=== Test Log ===");
        for (TestEntry entry : testLog) System.out.println(entry);

        System.out.println("\nProblems solved: " + getTotalProblemsSolved());
    }

    public void showDifficultySummary() {
        System.out.println("\n=== Problems Solved by Difficulty ===");
        for (Difficulty diff : Difficulty.values()) {
            int count = AnalyticsUtils.countSolvedByDifficulty(practiceLog, diff);
            System.out.println(diff + ": " + count);
        }
    }

    public void showStatsByPlatform() {
        Map<Platform, Integer> stats = AnalyticsUtils.countSolvedByPlatform(practiceLog);
        System.out.println("\n=== Problems Solved by Platform ===");
        for (Map.Entry<Platform, Integer> entry : stats.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    public void runMenu() {
        loadData();
        while (true) {
            System.out.println("\nSkillForge - Competitive Coding Tracker");
            System.out.println("1. Log Practice Activity");
            System.out.println("2. Log Test Participation");
            System.out.println("3. View All Entries");
            System.out.println("4. View Performance by Difficulty");
            System.out.println("5. View Stats by Platform");
            System.out.println("6. Exit");
            System.out.print("Select an option: ");

            String choice = scanner.nextLine();
            switch (choice) {
                case "1": addPracticeEntry(); break;
                case "2": addTestEntry(); break;
                case "3": showSummary(); break;
                case "4": showDifficultySummary(); break;
                case "5": showStatsByPlatform(); break;
                case "6": saveData(); System.out.println("Goodbye!"); return;
                default: System.out.println("Invalid option. Try again.");
            }
        }
    }

    public int getTotalProblemsSolved() {
        int count = 0;
        for (PracticeEntry entry : practiceLog)
            if ("Solved".equalsIgnoreCase(entry.status)) count++;
        return count;
    }
}
/*package skillforge;

import java.util.*;
import java.io.*;
import java.time.LocalDate;

public class SkillForgeApp {
    List<PracticeEntry> practiceLog = new ArrayList<>();
    List<TestEntry> testLog = new ArrayList<>();
    Scanner scanner = new Scanner(System.in);

    final String PRACTICE_FILE = "data/practice_log.csv";
    final String TEST_FILE = "data/test_log.csv";

    public void loadData() {
        practiceLog.clear();
        testLog.clear();
        try(BufferedReader br = new BufferedReader(new FileReader(PRACTICE_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) practiceLog.add(PracticeEntry.fromCSV(line));
            }
        } catch(IOException ignored) {}
        try(BufferedReader br = new BufferedReader(new FileReader(TEST_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) testLog.add(TestEntry.fromCSV(line));
            }
        } catch(IOException ignored) {}
    }

    public void saveData() {
        try(PrintWriter pw = new PrintWriter(PRACTICE_FILE)) {
            for (PracticeEntry entry : practiceLog) pw.println(entry.toCSV());
        } catch(IOException e) { System.out.println("Error saving practice log"); }

        try(PrintWriter pw = new PrintWriter(TEST_FILE)) {
            for (TestEntry entry : testLog) pw.println(entry.toCSV());
        } catch(IOException e) { System.out.println("Error saving test log"); }
    }

    public Platform selectPlatform() {
        while (true) {
            System.out.println("Select Platform:");
            int i = 1;
            for (Platform plat : Platform.values()) {
                System.out.printf("%d. %s\n", i++, plat);
            }
            System.out.print("Enter number (1-" + Platform.values().length + "): ");
            String input = scanner.nextLine();
            try {
                int choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= Platform.values().length) {
                    return Platform.values()[choice - 1];
                }
            } catch(NumberFormatException e) {}
            System.out.println("Invalid input. Try again.");
        }
    }

    public Difficulty selectDifficulty() {
        while (true) {
            System.out.println("Select Difficulty:");
            int i = 1;
            for (Difficulty diff : Difficulty.values()) {
                System.out.printf("%d. %s\n", i++, diff);
            }
            System.out.print("Enter number (1-" + Difficulty.values().length + "): ");
            String input = scanner.nextLine();
            try {
                int choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= Difficulty.values().length) {
                    return Difficulty.values()[choice - 1];
                }
            } catch(NumberFormatException e) {}
            System.out.println("Invalid input. Try again.");
        }
    }

    public void addPracticeEntry() {
        Platform platform = selectPlatform();
        System.out.print("Problem name: ");
        String problemName = scanner.nextLine();
        System.out.print("Date (YYYY-MM-DD, leave blank for today): ");
        String dateStr = scanner.nextLine();
        LocalDate date = dateStr.isEmpty() ? LocalDate.now() : LocalDate.parse(dateStr);
        System.out.print("Status (Solved/Attempted): ");
        String status = scanner.nextLine();
        Difficulty difficulty = selectDifficulty();
        System.out.print("Notes (optional): ");
        String notes = scanner.nextLine();

        practiceLog.add(new PracticeEntry(platform, problemName, date, status, difficulty, notes));
        saveData();
        System.out.println("Practice entry added!\n");
    }

    public void addTestEntry() {
        Platform platform = selectPlatform();
        System.out.print("Test name: ");
        String testName = scanner.nextLine();
        System.out.print("Date (YYYY-MM-DD, leave blank for today): ");
        String dateStr = scanner.nextLine();
        LocalDate date = dateStr.isEmpty() ? LocalDate.now() : LocalDate.parse(dateStr);
        System.out.print("Score: ");
        int score = Integer.parseInt(scanner.nextLine());
        System.out.print("Feedback: ");
        String feedback = scanner.nextLine();

        testLog.add(new TestEntry(platform, testName, date, score, feedback));
        saveData();
        System.out.println("Test entry added!\n");
    }

    public void showSummary() {
        System.out.println("\n=== Practice Log ===");
        for(PracticeEntry entry : practiceLog) System.out.println(entry);

        System.out.println("\n=== Test Log ===");
        for(TestEntry entry : testLog) System.out.println(entry);

        System.out.println("\nProblems solved: " + getTotalProblemsSolved());
    }

    public void showDifficultySummary() {
        System.out.println("\n=== Problems Solved by Difficulty ===");
        for (Difficulty diff : Difficulty.values()) {
            int count = AnalyticsUtils.countSolvedByDifficulty(practiceLog, diff);
            System.out.println(diff + ": " + count);
        }
    }

    public void showStatsByPlatform() {
        Map<Platform, Integer> stats = AnalyticsUtils.countSolvedByPlatform(practiceLog);
        System.out.println("\n=== Problems Solved by Platform ===");
        for(Map.Entry<Platform, Integer> entry : stats.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    public void runMenu() {
        loadData();
        while (true) {
            System.out.println("\nSkillForge - Competitive Coding Tracker");
            System.out.println("1. Log Practice Activity");
            System.out.println("2. Log Test Participation");
            System.out.println("3. View All Entries");
            System.out.println("4. View Performance by Difficulty");
            System.out.println("5. View Stats by Platform");
            System.out.println("6. Exit");
            System.out.print("Select an option: ");

            String choice = scanner.nextLine();
            switch (choice) {
                case "1": addPracticeEntry(); break;
                case "2": addTestEntry(); break;
                case "3": showSummary(); break;
                case "4": showDifficultySummary(); break;
                case "5": showStatsByPlatform(); break;
                case "6": saveData(); System.out.println("Goodbye!"); return;
                default: System.out.println("Invalid option. Try again.");
            }
        }
    }

    public int getTotalProblemsSolved() {
        int count = 0;
        for (PracticeEntry entry : practiceLog)
            if ("Solved".equalsIgnoreCase(entry.status)) count++;
        return count;
    }
}
/*package skillforge;

import java.util.*;
import java.io.*;
import java.time.LocalDate;

public class SkillForgeApp {
    List<PracticeEntry> practiceLog = new ArrayList<>();
    List<TestEntry> testLog = new ArrayList<>();
    Scanner scanner = new Scanner(System.in);

    final String PRACTICE_FILE = "data/practice_log.csv";
    final String TEST_FILE = "data/test_log.csv";

    // Supported platforms
    static final String[] PLATFORMS = {
        "LeetCode",
        "CodeChef",
        "Codeforces",
        "InterviewBit",
        "HackerRank",
        "HackerEarth",
        "AtCoder",
        "TakeUForward"
    };

    // Load all entries from file
    public void loadData() {
        practiceLog.clear();
        testLog.clear();

        // Load practice log
        try (BufferedReader br = new BufferedReader(new FileReader(PRACTICE_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) practiceLog.add(PracticeEntry.fromCSV(line));
            }
        } catch (IOException ignored) {}

        // Load test log
        try (BufferedReader br = new BufferedReader(new FileReader(TEST_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) testLog.add(TestEntry.fromCSV(line));
            }
        } catch (IOException ignored) {}
    }

    // Save all entries to file
    public void saveData() {
        try (PrintWriter pw = new PrintWriter(PRACTICE_FILE)) {
            for (PracticeEntry entry : practiceLog) pw.println(entry.toCSV());
        } catch (IOException e) { System.out.println("Error saving practice log"); }

        try (PrintWriter pw = new PrintWriter(TEST_FILE)) {
            for (TestEntry entry : testLog) pw.println(entry.toCSV());
        } catch (IOException e) { System.out.println("Error saving test log"); }
    }

    // Platform selection menu
    public String selectPlatform() {
        while (true) {
            System.out.println("Select Platform:");
            for (int i = 0; i < PLATFORMS.length; i++) {
                System.out.printf("%d. %s\n", i + 1, PLATFORMS[i]);
            }
            System.out.print("Enter number (1-" + PLATFORMS.length + "): ");
            String input = scanner.nextLine();
            try {
                int choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= PLATFORMS.length) {
                    return PLATFORMS[choice - 1];
                } else {
                    System.out.println("Invalid number. Try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    // Add a new practice entry
    public void addPracticeEntry() {
        String platform = selectPlatform();
        System.out.print("Problem name: ");
        String problemName = scanner.nextLine();
        System.out.print("Date (YYYY-MM-DD, leave blank for today): ");
        String dateStr = scanner.nextLine();
        LocalDate date = dateStr.isEmpty() ? LocalDate.now() : LocalDate.parse(dateStr);
        System.out.print("Status (Solved/Attempted): ");
        String status = scanner.nextLine();
        System.out.print("Difficulty (Easy/Medium/Hard): ");
        String difficulty = scanner.nextLine();
        System.out.print("Notes (optional): ");
        String notes = scanner.nextLine();

        practiceLog.add(new PracticeEntry(platform, problemName, date, status, difficulty, notes));
        saveData();
        System.out.println("Practice entry added!\n");
    }

    // Add a new test entry
    public void addTestEntry() {
        String platform = selectPlatform();
        System.out.print("Test name: ");
        String testName = scanner.nextLine();
        System.out.print("Date (YYYY-MM-DD, leave blank for today): ");
        String dateStr = scanner.nextLine();
        LocalDate date = dateStr.isEmpty() ? LocalDate.now() : LocalDate.parse(dateStr);
        System.out.print("Score: ");
        int score = Integer.parseInt(scanner.nextLine());
        System.out.print("Feedback: ");
        String feedback = scanner.nextLine();

        testLog.add(new TestEntry(platform, testName, date, score, feedback));
        saveData();
        System.out.println("Test entry added!\n");
    }

    // Show summary
    public void showSummary() {
        System.out.println("\n=== Practice Log ===");
        for (PracticeEntry entry : practiceLog) System.out.println(entry);

        System.out.println("\n=== Test Log ===");
        for (TestEntry entry : testLog) System.out.println(entry);

        System.out.println("\nProblems solved: " + getTotalProblemsSolved());
    }

    // Total solved problems by difficulty
    public void showDifficultySummary() {
        int easy = 0, medium = 0, hard = 0;
        for (PracticeEntry entry : practiceLog) {
            if ("Solved".equalsIgnoreCase(entry.status)) {
                switch (entry.difficulty.toLowerCase()) {
                    case "easy": easy++; break;
                    case "medium": medium++; break;
                    case "hard": hard++; break;
                }
            }
        }
        System.out.println("\n=== Problems Solved by Difficulty ===");
        System.out.println("Easy: " + easy);
        System.out.println("Medium: " + medium);
        System.out.println("Hard: " + hard);
        System.out.println("Total Solved: " + (easy + medium + hard));
    }

    // Stats by platform
    public void showStatsByPlatform() {
        Map<String, Integer> solvedByPlatform = new LinkedHashMap<>(); // Order preserved
        for (String plat : PLATFORMS) solvedByPlatform.put(plat, 0);

        for (PracticeEntry entry : practiceLog) {
            if ("Solved".equalsIgnoreCase(entry.status)) {
                String plat = entry.platform;
                solvedByPlatform.put(plat, solvedByPlatform.getOrDefault(plat, 0) + 1);
            }
        }
        System.out.println("\n=== Problems Solved by Platform ===");
        for (Map.Entry<String, Integer> p : solvedByPlatform.entrySet()) {
            System.out.println(p.getKey() + ": " + p.getValue());
        }
    }

    // Menu loop
    public void runMenu() {
        loadData();
        while (true) {
            System.out.println("\nSkillForge - Competitive Coding Tracker");
            System.out.println("1. Log Practice Activity");
            System.out.println("2. Log Test Participation");
            System.out.println("3. View All Entries");
            System.out.println("4. View Performance by Difficulty");
            System.out.println("5. View Stats by Platform");
            System.out.println("6. Exit");
            System.out.print("Select an option: ");

            String choice = scanner.nextLine();
            switch (choice) {
                case "1": addPracticeEntry(); break;
                case "2": addTestEntry(); break;
                case "3": showSummary(); break;
                case "4": showDifficultySummary(); break;
                case "5": showStatsByPlatform(); break;
                case "6": saveData(); System.out.println("Goodbye!"); return;
                default: System.out.println("Invalid option. Try again.");
            }
        }
    }

    // Count of solved problems
    public int getTotalProblemsSolved() {
        int count = 0;
        for (PracticeEntry entry : practiceLog)
            if ("Solved".equalsIgnoreCase(entry.status)) count++;
        return count;
    }
}
/*package skillforge;

import java.util.*;
import java.io.*;
import java.time.LocalDate;

public class SkillForgeApp {
    List<PracticeEntry> practiceLog = new ArrayList<>();
    List<TestEntry> testLog = new ArrayList<>();
    Scanner scanner = new Scanner(System.in);

    final String PRACTICE_FILE = "data/practice_log.csv";
    final String TEST_FILE = "data/test_log.csv";

    // Load all entries from file
    public void loadData() {
        practiceLog.clear();
        testLog.clear();

        // Load practice log
        try(BufferedReader br = new BufferedReader(new FileReader(PRACTICE_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) practiceLog.add(PracticeEntry.fromCSV(line));
            }
        } catch(IOException ignored) {}

        // Load test log
        try(BufferedReader br = new BufferedReader(new FileReader(TEST_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) testLog.add(TestEntry.fromCSV(line));
            }
        } catch(IOException ignored) {}
    }

    // Save all entries to file
    public void saveData() {
        try(PrintWriter pw = new PrintWriter(PRACTICE_FILE)) {
            for (PracticeEntry entry : practiceLog) pw.println(entry.toCSV());
        } catch(IOException e) { System.out.println("Error saving practice log"); }

        try(PrintWriter pw = new PrintWriter(TEST_FILE)) {
            for (TestEntry entry : testLog) pw.println(entry.toCSV());
        } catch(IOException e) { System.out.println("Error saving test log"); }
    }

    // Add a new practice entry
    public void addPracticeEntry() {
        System.out.print("Platform (LeetCode/CodeChef/HackerRank): ");
        String platform = scanner.nextLine();
        System.out.print("Problem name: ");
        String problemName = scanner.nextLine();
        System.out.print("Date (YYYY-MM-DD, leave blank for today): ");
        String dateStr = scanner.nextLine();
        LocalDate date = dateStr.isEmpty() ? LocalDate.now() : LocalDate.parse(dateStr);
        System.out.print("Status (Solved/Attempted): ");
        String status = scanner.nextLine();
        System.out.print("Difficulty (Easy/Medium/Hard): ");
        String difficulty = scanner.nextLine();
        System.out.print("Notes (optional): ");
        String notes = scanner.nextLine();

        practiceLog.add(new PracticeEntry(platform, problemName, date, status, difficulty, notes));
        saveData();
        System.out.println("Practice entry added!\n");
    }

    // Add a new test entry
    public void addTestEntry() {
        System.out.print("Platform: ");
        String platform = scanner.nextLine();
        System.out.print("Test name: ");
        String testName = scanner.nextLine();
        System.out.print("Date (YYYY-MM-DD, leave blank for today): ");
        String dateStr = scanner.nextLine();
        LocalDate date = dateStr.isEmpty() ? LocalDate.now() : LocalDate.parse(dateStr);
        System.out.print("Score: ");
        int score = Integer.parseInt(scanner.nextLine());
        System.out.print("Feedback: ");
        String feedback = scanner.nextLine();

        testLog.add(new TestEntry(platform, testName, date, score, feedback));
        saveData();
        System.out.println("Test entry added!\n");
    }

    // Show summary
    public void showSummary() {
        System.out.println("\n=== Practice Log ===");
        for(PracticeEntry entry : practiceLog) System.out.println(entry);

        System.out.println("\n=== Test Log ===");
        for(TestEntry entry : testLog) System.out.println(entry);

        System.out.println("\nProblems solved: " + getTotalProblemsSolved());
    }

    // Total solved problems by difficulty
    public void showDifficultySummary() {
        int easy = 0, medium = 0, hard = 0;
        for (PracticeEntry entry : practiceLog) {
            if ("Solved".equalsIgnoreCase(entry.status)) {
                switch (entry.difficulty.toLowerCase()) {
                    case "easy": easy++; break;
                    case "medium": medium++; break;
                    case "hard": hard++; break;
                }
            }
        }
        System.out.println("\n=== Problems Solved by Difficulty ===");
        System.out.println("Easy: " + easy);
        System.out.println("Medium: " + medium);
        System.out.println("Hard: " + hard);
        System.out.println("Total Solved: " + (easy + medium + hard));
    }

    // Menu loop
    public void runMenu() {
        loadData();
        while (true) {
            System.out.println("\nSkillForge - Competitive Coding Tracker");
            System.out.println("1. Log Practice Activity");
            System.out.println("2. Log Test Participation");
            System.out.println("3. View All Entries");
            System.out.println("4. View Performance by Difficulty");
            System.out.println("5. Exit");
            System.out.print("Select an option: ");

            String choice = scanner.nextLine();
            switch(choice) {
                case "1": addPracticeEntry(); break;
                case "2": addTestEntry(); break;
                case "3": showSummary(); break;
                case "4": showDifficultySummary(); break;
                case "5": saveData(); System.out.println("Goodbye!"); return;
                default: System.out.println("Invalid option. Try again.");
            }
        }
    }

    // Count of solved problems
    public int getTotalProblemsSolved() {
        int count = 0;
        for (PracticeEntry entry : practiceLog)
            if ("Solved".equalsIgnoreCase(entry.status)) count++;
        return count;
    }
}
*/

