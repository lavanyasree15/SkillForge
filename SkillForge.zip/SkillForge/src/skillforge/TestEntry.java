package skillforge;

import java.time.LocalDate;

public class TestEntry extends LogEntry implements CSVSerializable {
    Platform platform;
    String testName;
    int score;
    String feedback;

    public TestEntry(Platform platform, String testName, LocalDate date, int score, String feedback) {
        super(date);
        this.platform = platform;
        this.testName = testName;
        this.score = score;
        this.feedback = feedback;
    }

    @Override
    public String toString() {
        return date + " - [" + platform + "] " + testName + " | Score: " + score + " | Feedback: " + feedback;
    }

    @Override
    public String toCSV() {
        return String.join(",", platform.toString(), testName, date.toString(), Integer.toString(score), feedback);
    }

    public static TestEntry fromCSV(String csv) {
        String[] parts = csv.split(",", -1);
        return new TestEntry(
            Platform.valueOf(parts[0]),
            parts[1],
            LocalDate.parse(parts[2]),
            Integer.parseInt(parts[3]),
            parts[4]
        );
    }
}
/*package skillforge;

import java.time.LocalDate;

public class TestEntry {
    String platform;
    String testName;
    LocalDate date;
    int score;
    String feedback;

    public TestEntry(String platform, String testName, LocalDate date, int score, String feedback) {
        this.platform = platform;
        this.testName = testName;
        this.date = date;
        this.score = score;
        this.feedback = feedback;
    }

    @Override
    public String toString() {
        return date + " - [" + platform + "] " + testName + " | Score: " + score + " | Feedback: " + feedback;
    }

    public String toCSV() {
        return String.join(",", platform, testName, date.toString(), Integer.toString(score), feedback);
    }

    public static TestEntry fromCSV(String csv) {
        String[] parts = csv.split(",", -1);
        return new TestEntry(
            parts[0],
            parts[1],
            LocalDate.parse(parts[2]),
            Integer.parseInt(parts[3]),
            parts[4]
        );
    }
}
*/