package skillforge;

import java.time.LocalDate;

public class PracticeEntry extends LogEntry implements CSVSerializable {
    Platform platform;
    String problemName;
    String status;
    Difficulty difficulty;
    String notes;

    public PracticeEntry(Platform platform, String problemName, LocalDate date, String status, Difficulty difficulty, String notes) {
        super(date);
        this.platform = platform;
        this.problemName = problemName;
        this.status = status;
        this.difficulty = difficulty;
        this.notes = notes;
    }

    @Override
    public String toString() {
        return date + " - [" + platform + "] " + problemName + " (" + status + ", " + difficulty + ") - " + notes;
    }

    @Override
    public String toCSV() {
        return String.join(",", platform.toString(), problemName, date.toString(), status, difficulty.toString(), notes);
    }

    public static PracticeEntry fromCSV(String csv) {
        String[] parts = csv.split(",", -1);
        return new PracticeEntry(
            Platform.valueOf(parts[0]),
            parts[1],
            LocalDate.parse(parts[2]),
            parts[3],
            Difficulty.valueOf(parts[4]),
            parts[5]
        );
    }
}
