package skillforge;

import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

public class AnalyticsUtils {

    // Count solved problems by difficulty
    public static int countSolvedByDifficulty(List<PracticeEntry> entries, Difficulty difficulty) {
        int count = 0;
        for (PracticeEntry entry : entries) {
            if (entry.status != null && entry.difficulty != null) {
                if ("Solved".equalsIgnoreCase(entry.status) && entry.difficulty == difficulty) {
                    count++;
                }
            }
        }
        return count;
    }

    // Count solved problems by platform
    public static Map<Platform, Integer> countSolvedByPlatform(List<PracticeEntry> entries) {
        Map<Platform, Integer> stats = new LinkedHashMap<>();
        for (Platform plat : Platform.values()) stats.put(plat, 0);
        for (PracticeEntry entry : entries) {
            if (entry.status != null && entry.platform != null) {
                if ("Solved".equalsIgnoreCase(entry.status)) {
                    stats.put(entry.platform, stats.get(entry.platform) + 1);
                }
            }
        }
        return stats;
    }
}
/*package skillforge;

import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

public class AnalyticsUtils {
    public static int countSolvedByDifficulty(List<PracticeEntry> entries, Difficulty difficulty) {
        int count = 0;
        for (PracticeEntry entry : entries) {
            if ("Solved".equalsIgnoreCase(entry.status) && entry.difficulty == difficulty) {
                count++;
            }
        }
        return count;
    }

    public static Map<Platform, Integer> countSolvedByPlatform(List<PracticeEntry> entries) {
        Map<Platform, Integer> stats = new LinkedHashMap<>();
        for (Platform plat : Platform.values()) stats.put(plat, 0);
        for (PracticeEntry entry : entries) {
            if ("Solved".equalsIgnoreCase(entry.status)) {
                stats.put(entry.platform, stats.get(entry.platform) + 1);
            }
        }
        return stats;
    }
}
*/