package skillforge;

public interface CSVSerializable {
    String toCSV();
}
