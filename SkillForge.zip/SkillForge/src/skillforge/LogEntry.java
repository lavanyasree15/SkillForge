package skillforge;

import java.time.LocalDate;

public abstract class LogEntry {
    LocalDate date;

    public LogEntry(LocalDate date) {
        this.date = date;
    }
    public LocalDate getDate() { return date; }
    public abstract String toString();
}
